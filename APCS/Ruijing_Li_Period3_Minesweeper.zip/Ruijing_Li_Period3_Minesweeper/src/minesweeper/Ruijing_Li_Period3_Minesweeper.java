/* Ruijing Li
 * Period 3
 * 4/3/14
 * Time Spent: 8 hours of debugging and making.
 * FINALLY DONE. Took a long long time, but finally got it working. Lots of bugs, debugging,
 * and stuff. Should work when run. Title changes whether you win or lose and you
 * click the board again to reset. Hopefully working properly. Also compiled using netbeans gui editor which
 * was of great help. All I have to say is 
 * SUCH GOOD MUCH FUN GG NO RE PL0X.
 */

package minesweeper;

/**
 *
 * @author admin
 */
public class Ruijing_Li_Period3_Minesweeper {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ruijing_Li_Period3_MyJFrame.main(args);
    }
    
}
